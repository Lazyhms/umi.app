import RemoteSelect from './Select/RemoteSelect';

export default RemoteSelect;
