import { AxiosResponse } from '@umijs/max';
import { request } from '@umijs/max';
import { Select, SelectProps } from 'antd';
import React, { useState } from 'react';

type IResponseInterceptor = <T = any>(response: AxiosResponse<T>) => AxiosResponse<T>;

interface remoteConfig {
    url: string | null;
    pageSize?: number;
    responseInterceptors?: IResponseInterceptor;
}

interface RemoteSelectProps extends SelectProps {
    remote?: remoteConfig;
}

interface OptionPagedItem {
    data: any[];
    totalPage: number;
}

const RemoteSelect: React.FC<RemoteSelectProps> = (props) => {
    const { options, remote, } = props;

    const [pageIndex, setItemPage] = useState(0);
    const [loading, setLoading] = useState(false);
    const [optionsItem, setOptionsItem] = useState<OptionPagedItem>({ data: options ?? [], totalPage: 1 });

    const getItems = async () => {
        if ((remote?.url ?? '') === '') {
            return;
        }

        const tempPageIndex = pageIndex + 1;

        if (tempPageIndex > optionsItem.totalPage) {
            return;
        }

        setItemPage(tempPageIndex);

        await request(remote!.url!, {
            params: {
                pageIndex,
                pageSize: remote!.pageSize ?? 10
            },
            responseInterceptors: remote?.responseInterceptors === null ? [] : [remote!.responseInterceptors!]
        }).then(e => {
            setOptionsItem({ data: [...optionsItem.data!, ...e.data], totalPage: e.totalPage });

            setLoading(false);
        });
    }

    const handleDropdownVisibleChange = async (open: boolean) => {
        if (open && (optionsItem?.data.length ?? 0) === (options?.length ?? 0) && (remote ?? '') !== '') {
            setLoading(true);

            await getItems();
        }
    }

    const handlePopupScroll = async (e: any) => {
        e.persist();

        const { scrollTop, offsetHeight, scrollHeight } = e.target;
        if (scrollTop + offsetHeight === scrollHeight) {
            await getItems();
        }
    }

    return (
        <Select
            {...props}
            options={optionsItem.data}
            loading={loading}
            filterOption={false}
            onPopupScroll={handlePopupScroll}
            onDropdownVisibleChange={handleDropdownVisibleChange}
        />
    );
};

export default RemoteSelect;