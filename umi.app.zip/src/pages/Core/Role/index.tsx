import RemoteSelect from "@/components";
import { useState } from "react";

const TableList: React.FC<unknown> = () => {

    //不推荐这么玩
    //此操作是为了处理获取更多数据情况，一般不需要这么处理
    //onSelect事情中可直接获取到选中值了
    const [items, setItems] = useState<any[]>([]);

    return (
        <>
            <RemoteSelect
                defaultValue={null}
                options={[{
                    label: '请选择',
                    value: null,
                    disabled: false,
                }]} remote={{
                    url: "/api/dorpDown/roles",
                    pageSize: 10,
                    responseInterceptors: (e: any) => {
                        const current = (e.data.data).map((d: any) => {
                            return {
                                label: `[${d.value}]${d.label}`,
                                code: "0",
                                value: d.value
                            };
                        });
                        setItems([...items, ...current]);
                        e.data.data = current;
                        return e;
                    }
                }} onSelect={(e) => {
                    const item = items.find(f => f.value === e);
                    console.log(item);
                }}
            ></RemoteSelect >
            <label> {new Date().format("yyyy-MM-dd")}</label>
        </>
    );
}

export default TableList;