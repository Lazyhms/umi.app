interface Date {
    format(formatStr: string): string
}