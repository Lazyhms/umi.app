interface String {
    isNullOrEmpty(): boolean
    isNullOrWhiteSpace(): boolean
}