interface FormData {
    toJson(): any
}